window.mainPage.innerHTML += `
<div id = 'header'>
<h1>MyMovies</h1>
<p>Use this app to save your favourite movies from all time! 
You can sort them by rating, year, etc and share them with your 
stupid friends!</p>
</div>
`;